/*
 *  ServerPacketInterpreter.java
 *  
 *  Class that interprets received packets from
 *  client and then performs certain actions.
 *  
 */

package set.server;

import java.io.DataInputStream;

import set.packet.DataReader;

public class ServerPacketInterpreter {

	/******************************/
	/** PacketInterpreter fields **/
	/******************************/
	
	public DataInputStream packet;
	
	/*******************************/
	/** PacketInterpreter methods **/
	/*******************************/
	
	
	
}
