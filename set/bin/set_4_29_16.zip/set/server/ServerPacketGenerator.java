/*
 *  ServerPacketGenerator.java
 *  
 *  Class that creates functions to generate
 *  all different packet possibilities to be
 *  sent from server to client.
 *  
 */

package set.server;

import java.io.DataOutputStream;

import set.packet.DataWriter;

public class ServerPacketGenerator {
	
	/****************************/
	/** PacketGenerator fields **/
	/****************************/
	
	public DataOutputStream packet;
	
	/*****************************/
	/** PacketGenerator methods **/
	/*****************************/
	
	// Packet telling client to go to login state
	public DataOutputStream GoToLogin() {
		
		DataWriter dataWriter = new DataWriter();
		short header = 0;
		int state = 0;
		
		dataWriter.WriteShort(header, packet);
		dataWriter.WriteInt(state, packet);
		
		return packet;
	}
	
	// Packet telling client to go to lobby state
	public DataOutputStream GoToLobby() {
		
		DataWriter dataWriter = new DataWriter();
		short header = 0;
		int state = 1;
		
		dataWriter.WriteShort(header, packet);
		dataWriter.WriteInt(state, packet);
		
		return packet;
	}
	
	// Packet telling client to go to game room state
	public DataOutputStream GoToGameRoom() {
		
		DataWriter dataWriter = new DataWriter();
		short header = 0;
		int state = 2;
		
		dataWriter.WriteShort(header, packet);
		dataWriter.WriteInt(state, packet);
		
		return packet;
	}
	
	// Packet telling client to go to game state
	public DataOutputStream GoToGame() {
		
		DataWriter dataWriter = new DataWriter();
		short header = 0;
		int state = 3;
		
		dataWriter.WriteShort(header, packet);
		dataWriter.WriteInt(state, packet);
		
		return packet;
	}
	
	// Packet sending client player data
	public DataOutputStream PlayerData(String username, int userID,
							int numWins, int numTotalGames,
							int score, int highScore) {
		
		DataWriter dataWriter = new DataWriter();
		short header = 1;
		
		dataWriter.WriteShort(header, packet);
		dataWriter.WriteString(username, packet);
		dataWriter.WriteInt(userID, packet);
		dataWriter.WriteInt(numWins, packet);
		dataWriter.WriteInt(numTotalGames, packet);
		dataWriter.WriteInt(score, packet);
		dataWriter.WriteInt(highScore, packet);
		
		return packet;
	}
	
	// Packet notifying that set has been found
	public DataOutputStream GameEventYouFoundSet() {
		
		DataWriter dataWriter = new DataWriter();
		short header = 2;
		int event = 0;
		
		dataWriter.WriteShort(header, packet);
		dataWriter.WriteInt(event, packet);
		
		return packet;
	}
	
	// Packet notifying that set has been found
	public DataOutputStream GameEventOtherPlayerFoundSet(String username) {
		
		DataWriter dataWriter = new DataWriter();
		short header = 2;
		int event = 1;
		
		dataWriter.WriteShort(header, packet);
		dataWriter.WriteInt(event, packet);
		dataWriter.WriteString(username, packet); // user who found set
		
		return packet;
	}
	
	// Packet notifying that set has been found
	public DataOutputStream GameEventYouWon() {
		
		DataWriter dataWriter = new DataWriter();
		short header = 2;
		int event = 2;
		
		dataWriter.WriteShort(header, packet);
		dataWriter.WriteInt(event, packet);
		
		return packet;
	}
	
	// Packet notifying that set has been found
	public DataOutputStream GameEventOtherPlayerWon(String username) {
		
		DataWriter dataWriter = new DataWriter();
		short header = 2;
		int event = 3;
		
		dataWriter.WriteShort(header, packet);
		dataWriter.WriteInt(event, packet);
		dataWriter.WriteString(username, packet); // user who won
		
		return packet;
	}
	
}