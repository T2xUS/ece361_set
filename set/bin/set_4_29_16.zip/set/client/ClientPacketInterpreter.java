/*
 *  ClientPacketInterpreter.java
 *  
 *  Class that interprets received packets from
 *  server and then performs certain actions.
 *  
 */


package set.client;

import java.io.DataInputStream;

import set.packet.DataReader;

public class ClientPacketInterpreter {

	/******************************/
	/** PacketInterpreter fields **/
	/******************************/
	
	public DataInputStream packet;
	
	/*******************************/
	/** PacketInterpreter methods **/
	/*******************************/
	
	
}
