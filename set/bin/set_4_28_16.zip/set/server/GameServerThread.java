package set.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import set.server.game.Game;
import set.server.game.GamePlayer;

// Note: This class will be referred to as the "client",
// since each server thread manages a client connection.
public class GameServerThread extends Thread {

	/*****************************/
	/** GameServerThread fields **/
	/*****************************/

	private Socket clientSocket;
	private DataInputStream clientInData;
	private DataOutputStream clientOutData;
	private boolean ClientOn = true;
	
	private GamePlayer player;

	/**********************************/
	/** GameServerThread constructor **/
	/**********************************/

	public GameServerThread(Socket cSocket) {
		super(); // call Thread constructor
		clientSocket = cSocket;
		player = new GamePlayer(this);
	}

	/******************************/
	/** GameServerThread methods **/
	/******************************/
	
	/********************/
	/** Player-related **/
	/********************/
	
	// Get client of the player
	public GameServerThread GetClient() {
		return this;
	}
	
	// Get user ID of player associated with client
	public int GetUserID() {
		return player.userID;
	}
	
	// Get username of player associated with client
	public String GetUserName() {
		return player.username;
	}
	
	// Get score of player associated with client
	public int GetScore() {
		return player.score;
	}
	
	// Get highscore of player associated with client
	public int GetHighScore() {
		return player.highscore;
	}
	
	// Get wins of player associated with client
	public int GetWins() {
		return player.numWins;
	}
	
	// Get total play count of player associated with client
	public int GetTotalGames() {
		return player.totalGames;
	}
	
	// Increase player's number of wins
	public int IncreaseWins() {
		return player.numWins++;
	}
	
	// Increase player's total number of games
	public int IncreaseTotalGames() {
		return player.totalGames++;
	}
	
	// Put player in lobby
	public void AddPlayerToLobby() {
		player.EnterGameLobby();
		//send packet
	}
	
	// Kick player from game room
	public void KickPlayerFromGameRoom() {
		player.ExitGameRoom();
		player.EnterGameLobby();
		//send packet
	}
	
	// Put client in game
	public void AddPlayerToGame() {
		player.JoinGame(player.gameRoom.hostUID);
		//send packet
	}
	
	// Kick player from game
	public void KickPlayerFromGame() {
		player.ExitGame();
		player.EnterGameLobby();
		//send packet
	}

	
	/********************/
	/** Client-related **/
	/********************/
	
	// Close client
	public void Close() {
		ClientOn = false;
	}
	
	/********************/
	/** Packet-related **/
	/********************/
	
	// Parse packets from server
	public void ParsePacket() throws IOException {
		
		short header = clientInData.readShort();
		switch(header) {
		
		case 0x00:
			System.out.println("Starting game...");
			Game NewGame = new Game();
			clientOutData.writeShort(0x00);
			clientOutData.writeInt(NewGame.CardsOnField());
			clientOutData.writeUTF(NewGame.boardString());
			clientOutData.flush();
			break;
		
		/*
		case 0x00:
			System.out.println("First name: " + clientInData.readUTF());
			System.out.println("Last name: " + clientInData.readUTF());
			break;
			
		case 0x01:
			System.out.println("User: " + clientInData.readUTF());
			System.out.println("Pass: " + clientInData.readUTF());
			System.out.println("Highscore: " + clientInData.readInt());
			System.out.println("Win count: " + clientInData.readInt());
			break;
		*/
		}
	}

	/**************************/
	/** GameServerThread run **/
	/**************************/

	public void run() {
		
		System.out.println("GameServerThread: Client is running!");
		
		try {
			clientInData = new DataInputStream(clientSocket.getInputStream());
			clientOutData = new DataOutputStream(clientSocket.getOutputStream());
		} catch (IOException e) {
			System.err.println("GameServerThread: Error opening IO stream ");
		}
		
		while(ClientOn) {
			try {
				int availableBytes = clientInData.available();
				if(availableBytes > 0) {
					ParsePacket();
				}
			} catch (IOException e) {
				System.err.println("GameServerThread: Error parsing packet.");
			}
		}
	}
	
}

