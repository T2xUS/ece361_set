package set.packet;

import java.io.DataOutputStream;

public class PacketGenerator {
	
	/****************************/
	/** PacketGenerator fields **/
	/****************************/
	
	public DataOutputStream packet;
	
	/*********************************/
	/** PacketGenerator constructor **/
	/*********************************/
	
	public PacketGenerator() {
		
		
	}

	/*****************************/
	/** PacketGenerator methods **/
	/*****************************/
	
	public DataOutputStream PlayerData(String username, int userID,
							int numWins, int numTotalGames,
							int score, int highScore) {
		
		DataWriter dataWriter = new DataWriter();
		dataWriter.WriteShort(0x01, packet);
		
		return packet;
	}
	
}