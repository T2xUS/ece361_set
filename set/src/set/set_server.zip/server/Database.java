package set.server;

public class Database {

	public String username = "supahotfiya7";
	public int userID;
	public int numWins = 0;
	public int numTotalGames = 0;
	public int score = 0;
	public int highScore = -1;
	
}
